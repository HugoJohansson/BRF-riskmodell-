# BRF-riskmodell

Upplägg för en modell över hur ekonomin i en bostadsrättsförening kan utvecklas under olika framtidsscenarier, och vilka risker som kan tvinga fram avgiftshöjningar.

**Status:** Det här är en skiss på upplägget, indata och förhoppningsvis tänkt utdata. Tentaperiod, jobb och annat kom emellan, så ingen kod eller data är gjord än. Underhållsplanen ska uppdateras snart, och det kan vara bra att vänta in den för att få mer data.

Föreningen har 18 lägenheter, värms med fjärrvärme och ligger i Uppsala. Föreningens egna siffror ligger inte i repot.

## Frågor modellen ska besvara

- Hur stor är sannolikheten att avgiften behöver höjas med mer än 10 % inom 5 respektive 10 år?
- Räcker underhållsfonden för de planerade åtgärderna, och hur ser det ut i sämre fall?
- Vilka drivkrafter förklarar mest av osäkerheten: räntor, energipriser eller klimat?
- Vilka beslut bör styrelsen ta nu, och vilka kan vänta?

## Horisonter

| Horisont | Används till |
|---|---|
| 5 år | Kortsiktig likviditet: räcker fonden och kan lånen betalas? |
| 10 år | Nästa avgiftsbeslut och större underhållscykler |
| 30 år | En full underhållscykel, med fasad, stammar och tak |
| 50 år | Livslängdsfrågor och stora investeringar |

Styrelsen ska först se 5 och 10 år, eftersom de är minst osäkra. För 30 och 50 år används en livslängdsmodell i stället för underhållsplanen, som då är föråldrad. Kostnaderna räknas i framtida kronor med kostnadsinflation.

## Moduler

1. **Risk och scenarier** för hela föreningen. Den görs först.
2. **Dränering:** risken för vattenskador mot kostnaden för att åtgärda nu. Föreningen har prioriterat dränering före fönster.
3. **Fönsterbyte:** energibalans, klimateffekt och återbetalningstid.
4. **Solpaneler:** produktion mot föreningens gemensamma elbehov.
5. **Värmepump eller bergvärme mot fjärrvärme:** kostnad per levererad kWh värme.

Modul 2–5 väntar tills riskmodulen fungerar.

## Indata

Underhållsplanen är första källan. Varje komponent har samma kolumner, så att en ny plan kan ersätta den gamla rad för rad. Se [`data/underhallsplan_mall.csv`](data/underhallsplan_mall.csv).

| Värde | Källa | Osäkerhet |
|---|---|---|
| Lån och räntor | Årsredovisning | Låg |
| Avgiftsintäkter | Årsredovisning | Låg |
| Underhållsåtgärder och kostnader | Underhållsplan, besiktning | Hög |
| Graddagar | SMHI | Medel |
| Elpris SE3 | Nord Pool | Hög |
| Styrränta | Riksbanken | Medel |

Varje värde ska ha en källa och en bedömd osäkerhet. Antaganden utan källa markeras.

## Drivkrafter

- **Räntor:** Riksbankens styrränta och bolånemarginaler
- **Inflation:** KPI och byggkostnadsindex
- **Energi:** fjärrvärmepris och elpris i SE3
- **Klimat:** graddagar, värmeböljor, skyfall, vattenskador och försäkringspremier, utifrån SMHI:s scenarier för Uppsala
- **Omvärld:** energichocker och valutaeffekter som slår mot byggpriser och räntor

Klimatprojektioner säger mer om trender och hur ofta något händer än om exakta belopp. De används för att välja scenarier, inte som prognoser.

## Scenarier

| Scenario | Antagande |
|---|---|
| Bas | Historisk trend för räntor, priser och skador |
| Höga räntor | Hög inflation och höga räntor i flera år |
| Energichock | Fjärrvärme och el dubbelt så dyra under en period |
| Klimatskada | Ett skyfall ger en vattenskada och en åtgärd som inte kan vänta |
| Worst case | Höga räntor, energichock och klimatskada samtidigt |

Siffrorna för varje scenario sätts när indata är klara.

## Utdata

- Sannolikheten för en avgiftshöjning på mer än 10 % inom 5 och 10 år
- Underhållsfondens saldo som percentiler (10:e och 90:e) för varje horisont
- En känslighetsanalys som visar hur mycket av utfallet varje drivkraft förklarar

## AI-användning

Se [`AI-DEKLARATION.md`](AI-DEKLARATION.md).
