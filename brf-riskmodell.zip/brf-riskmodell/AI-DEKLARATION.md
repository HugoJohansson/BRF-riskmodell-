# AI-deklaration

Det här upplägget är gjort med hjälp av Claude (Anthropic) i oktober–november 2026.

## Vad jag har gjort

- Valt idén och syftet: en risk- och scenariomodell för min egen bostadsrättsförening.
- Bestämt vilka frågor modellen ska svara på och vilka horisonter styrelsen ska se först.
- Tagit fram fakta om föreningen, som antal lägenheter, uppvärmning, lån och vilka åtgärder som är på gång.
- Prioriterat modulerna, med risk först och dränering före fönster.
- Granskat och godkänt innehållet innan publicering.

## Vad Claude har gjort

- Föreslagit struktur för dokumentet och modulerna.
- Föreslagit drivkrafter, scenarier, utdata och möjliga datakällor.
- Formulerat och redigerat texten, och gjort om den till README och CSV-mall för det här repot.

## Ansvar

Jag står för innehållet. Förslag från Claude har jag läst och valt att ta med, ändra eller stryka. Ingen kod eller beräkning finns ännu. När modellen byggs uppdateras den här filen med vad AI har använts till där.

Hugo Johansson
